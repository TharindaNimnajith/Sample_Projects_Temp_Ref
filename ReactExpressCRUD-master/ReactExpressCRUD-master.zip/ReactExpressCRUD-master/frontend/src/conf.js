export const proxy = 'http://localhost:5000/api/'
