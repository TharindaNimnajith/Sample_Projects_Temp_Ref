module.exports = {
    mongoURI : 'mongodb+srv://gihan:gihan123@employeedb-binj9.mongodb.net/test?retryWrites=true'
}
