import React from 'react';

import './App.css';
import SignUp from "./Components/SignUp/SignUp";

function App() {
  return (
    <div className="App">
     <h1>Hello</h1>
        <SignUp/>
    </div>
  );
}

export default App;
