import React from 'react'

function About(){
    return (
        
        <React.Fragment>
            <h1>This is the about page</h1>
            <p>My6 first react application</p>
        </React.Fragment>
    )
}

export default About;