﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InventoryManagementSystem
{
    public static class GlobalValues
    {

        /*colors 
         * 
         * 
         */

        public static Color MAINCOLOR = Color.FromArgb(2237489);
        public static Color BUTTON_COLOR = Color.SteelBlue;


    }
}
