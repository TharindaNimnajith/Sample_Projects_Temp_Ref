export default {
  primaryColor: "#f07800",
  accentColor: ""
};
