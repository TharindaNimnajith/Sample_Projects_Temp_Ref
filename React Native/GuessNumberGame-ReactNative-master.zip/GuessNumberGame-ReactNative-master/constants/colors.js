export default {
  primaryColor: "#f7287b",
  accentColor: "#f217bd"
};
