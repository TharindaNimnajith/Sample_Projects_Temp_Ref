export default {
  primary: "#9D1547",
  accent: "#E5326E",
  blackText: "#5B5656",
  whiteText: "#F3F1F1",
};
